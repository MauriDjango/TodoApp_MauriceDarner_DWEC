import React, { useState } from 'react'

const Formulario = () => {

  const initialValue = {
    title:"Tarea 1",
    description:"Descripcion 1",
    state:"completada",
    priority:false
  }

  const [todo, setTodo] = useState(initialValue)

  const handleSubmit = e => {
    e.preventDefault()
    console.log(`Enviando ${todo.title}, ${todo.description}, ${todo.state}, ${todo.priority}`)
  }

  const handleChange = e => {
    const {name, value, checked, type} = e.target
    setTodo({
      ...todo,
     [name]:type === "checkbox" ? checked : value

    })
  }

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input 
          type="text" 
          name="title" 
          placeholder='Introduce la tarea'
          className='form-control mb-2'
          value = {todo.title}
          onChange={handleChange}
        />
        <textarea 
          name="description" 
          placeholder='Introduce la descripcion'
          className='form-control mb-2'
          value = {todo.description}
          onChange={handleChange}
          />
          <select 
            name="state" 
            className='form-control mb-2'
            value = {todo.state}
            onChange={handleChange}

            >
            <option value="pendiente">pendiente</option>
            <option value="completada">completada</option>
          </select>
          <div className='form-checked mb2'>
              <input 
                className='form-checked mb2'
                type="checkbox" 
                name="priority" 
                id="inputCheck"
                checked={todo.priority}
                onChange={handleChange}
                />
                <label 
                  className='form-checked mb2'
                  htmlFor="inputCheck"
                  >
                    Prioridad
                </label>
          </div>

          <button
            type='submit'
            className='btn btn-primary'
          >
            Añadir
          </button>
      </form>
    </div>
  )
}

export default Formulario